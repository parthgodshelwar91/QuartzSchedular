﻿using Quartz;
using System.Net.Http;

namespace QuartzSchedular.Jobs
{
    public class ApiCallerJob : IJob
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public ApiCallerJob(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task Execute(IJobExecutionContext context)
        {
            // Set the fixed log directory
            var logDir = @"C:\Users\parth.godshelwar\Desktop\encryption\QuartzSchedular\QuartzSchedular\log";
            var logFile = Path.Combine(logDir, "scheduler.log");
            Directory.CreateDirectory(logDir);

            try
            {
                var client = _httpClientFactory.CreateClient();
                var response = await client.GetAsync("https://jsonplaceholder.typicode.com/posts/1");
                var content = await response.Content.ReadAsStringAsync();

                var successLog = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} ✅ API call success. Response: {content}{Environment.NewLine}";
                Console.WriteLine(successLog);
                await File.AppendAllTextAsync(logFile, successLog);
            }
            catch (Exception ex)
            {
                var errorLog = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} ❌ Error: {ex.Message}{Environment.NewLine}";
                Console.WriteLine(errorLog);
                await File.AppendAllTextAsync(logFile, errorLog);
            }
        }
    }
}
